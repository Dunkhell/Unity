﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RuchPotwora : MonoBehaviour
{
    public GameObject Wróg;
    public Rigidbody2D rb;
    Jednostka Potwór;
    Vector2 move;
    int iloscKroków = 5;

    public void Start()
    {
        Potwór = Wróg.GetComponent<Jednostka>();
    }
    public void Update()
    {
        if (iloscKroków == 10)
        {
            iloscKroków = 0;
            int num = Random.Range(1, 25);
            switch (num)
            {
                case 1:
                    {
                        move = new Vector2(10, 0);
                        break;
                    }
                case 2:
                    {
                        move = new Vector2(-10, 0);
                        break;
                    }
                case 3:
                    {
                        move = new Vector2(0, 10);
                        break;
                    }
                case 4:
                    {
                        move = new Vector2(0, -7);
                        break;
                    }
                case 5:
                    {
                        move = new Vector2(7, 7);
                        break;
                    }
                case 6:
                    {
                        move = new Vector2(-7, -7);
                        break;
                    }
                case 7:
                    {
                        move = new Vector2(-7, 7);
                        break;
                    }
                case 8:
                    {
                        move = new Vector2(7, -7);
                        break;
                    }
                default:
                    {
                        move = new Vector2(0, 0);
                        break;
                    }
            }
        }
        else
        {
            iloscKroków++;
        }
    }


    void FixedUpdate()
    {
        rb.MovePosition(rb.position + move * Potwór.MoveSpeed * Time.fixedDeltaTime);
    }
}