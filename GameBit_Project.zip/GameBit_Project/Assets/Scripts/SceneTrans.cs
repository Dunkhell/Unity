﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneTrans : MonoBehaviour
{
    public GameObject guiObject; // Określanie jaki element UI się pojawi 
    public string sceneToLoad;  // Elastyczna zmiana na która scenę nas załaduje z widoku silnika

    private void Start()
    {
        guiObject.SetActive(false); //automatyczne wyłączenie elementu UI
        
    }
     void OnTriggerEnter2D(Collider2D other)
    {
       
        if(other.CompareTag("Player"))
        {
            guiObject.SetActive(true);
            
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if(Input.GetKeyDown("e"))
            {
                SceneManager.LoadScene(sceneToLoad);  // po wcisnięciu klawisza w.w. załaduje się scena której nazwę podajemy w silniku
            }
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            guiObject.SetActive(false);
        }
    }
}
