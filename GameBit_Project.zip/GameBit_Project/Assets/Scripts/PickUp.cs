﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PickUp : MonoBehaviour
{
    public GameObject guiObject;
    public GameObject myItem;
    private Inventory inventory;

   void Start()
    {
        guiObject.SetActive(false);
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<Inventory>();
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            guiObject.SetActive(true);
        }
    }
    public void OnTriggerStay2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
         if (Input.GetKeyDown("e"))
         {
                for (int i = 0; i < inventory.slots.Length; i++)
                {
                    if(inventory.isFull[i] == false)
                    {
                        guiObject.SetActive(false);
                        inventory.isFull[i] = true;
                        Instantiate(myItem, inventory.slots[i].transform,false);
                        Destroy(gameObject);
                        break;
                    }
                }

         }
        }
    }
    public void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            guiObject.SetActive(false);
        }
    }

}
