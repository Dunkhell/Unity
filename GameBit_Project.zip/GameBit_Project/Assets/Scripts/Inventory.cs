﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public bool[] isFull;
    public GameObject[] slots;
    public GameObject backpack;
    private bool isOpen;

    private void Start()
    {
        isOpen = false;
        backpack.SetActive(false);
    }

    public void Update ()
    {
        if (Input.GetKeyDown("b"))  // Otwieranie plecaka za pomocą przycisku
        {

            if (isOpen == false)
            {
                backpack.SetActive(true);
                Time.timeScale = 0;
                isOpen = true;
            }
            else if (isOpen == true)
            {
                backpack.SetActive(false);
                Time.timeScale = 1;
                isOpen = false;
            }


        }   
    }
}
