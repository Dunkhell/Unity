using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Analytics.DataPrivacy.Tests")]
[assembly: InternalsVisibleTo("Unity.Analytics.DataPrivacy.WebRequest.Tests")]
